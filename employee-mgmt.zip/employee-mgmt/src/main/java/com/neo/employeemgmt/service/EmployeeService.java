package com.neo.employeemgmt.service;

import com.neo.employeemgmt.model.Employee;

import java.util.List;

public interface EmployeeService {
    Employee saveEmployee(Employee employee);
    List<Employee> getAllEmployees();
    Employee getEmployeeById(Long id);
    Employee updateEmployee(Employee employee,Long id);
    void deleteEmployee(Long id);
}
